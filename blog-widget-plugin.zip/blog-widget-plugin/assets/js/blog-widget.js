// Blog Widget Scripts
(function ($) {
  $(document).ready(function () {
    console.log("Blog Widget Loaded");
  });
})(jQuery);
