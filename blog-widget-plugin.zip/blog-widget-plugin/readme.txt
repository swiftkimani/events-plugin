=== Blog Widget Plugin ===
Contributors: yourname
Tags: blog, widget, filter, pagination
Requires at least: 5.0
Tested up to: 6.3
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A plugin that adds a widget for the native WordPress blog with a beautiful UI, filter section, and pagination.

== Description ==

This plugin provides a customizable widget to display blog posts with:

* A filter section for categories and dates.
* Pagination at both the top and bottom of the blog list.
* A responsive and modern design.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/blog-widget-plugin` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Add the "Blog Widget" to your desired widget area through the 'Widgets' screen in WordPress.

== Changelog ==

= 1.0 =
* Initial release.